package testcase4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import pages.Dashboard;
import pages.MyProfile;

public class Regions {

	WebDriver dr;
	WebElement we;
	Select sl;
	MyProfile mp;
	Dashboard db;
	Regions rg;
	//By regions_link=By.xpath("//*[@id=\"menu-posts-property\"]/ul/li[5]/a");
	By name_regions=By.name("tag-name");
	By slug_regions=By.name("slug");
	By dropdown_regions=By.xpath("//*[@id=\"parent\"]");
	By description_regions=By.xpath("//*[@id=\"tag-description\"]");
	By button_regions=By.xpath("//*[@id=\"submit\"]");
	
	public void login_regions(){
		mp=new MyProfile(dr);
		mp.login();
	}
	public Regions(WebDriver dr){
		this.dr=dr;
	}
	public void regions_name(){
		dr.findElement(name_regions).sendKeys("Honey");
	}
	public void regions_slug(){
		dr.findElement(slug_regions).sendKeys("launch");
	}
	public void regions_dropdown(){
		we=dr.findElement(dropdown_regions);
		sl=new Select(we);
		sl.selectByVisibleText("None");
	}
	public void regions_description(){
		dr.findElement(description_regions).sendKeys("New Launches of vilas, apartments, flats");
	}
	public void regions_button(){
		dr.findElement(button_regions).click();
	}
	
	public void regions() throws InterruptedException{
		rg=new Regions(dr);
		db=new Dashboard(dr);
		rg.login_regions();
		db.properties();
    	db.regions_link();
		rg.regions_name();
		rg.regions_slug();
		rg.regions_dropdown();
		rg.regions_description();
		rg.regions_button();
	}
	
}
