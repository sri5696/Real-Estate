package testng;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.Dashboard;
import pages.LaunchBrowser;

import pages.MyProfile;
import testcase1.AllProperties;
import testcase2.Features;
import testcase3.FeaturesToDelete;
import testcase4.Regions;
import testcase5.RegionsToDelete;

public class TestForFirefox {
	WebDriver dr;
	LaunchBrowser lb;
	MyProfile mp;
	Dashboard db;
	AllProperties ap;
	Features feat;
	FeaturesToDelete ftd;
	Regions rg;
	RegionsToDelete rtd;
	String autURL1,nodeURL1;
@BeforeMethod
public void realestate() throws MalformedURLException {
	
	  autURL1 = "http://realestate.upskills.in/";
	  nodeURL1 = "http://172.24.98.36:5566/wd/hub";
	  DesiredCapabilities cap = DesiredCapabilities.firefox();
	  cap.setBrowserName("firefox");
	  cap.setPlatform(Platform.WINDOWS);
	  dr = new RemoteWebDriver(new URL(nodeURL1), cap);
	  dr.get(autURL1);
	}
 @Test(priority=0)
public void allproperties() throws InterruptedException {
	  ap=new AllProperties(dr);	  
	   ap.allproperties1();
	   dr.close();
}
@Test(priority=2)
public void featurestestcase() throws InterruptedException{
	  feat=new Features(dr);
	  feat.featurestotest();
	  dr.close();
}
@Test(priority=4)
public void featuretodelete() throws InterruptedException{
	  ftd=new FeaturesToDelete(dr);
	  ftd.featurestodelete();
	  dr.close();
}
@Test(priority=6)
 public void regionstestcase() throws InterruptedException{
	  rg=new Regions(dr);
	  rg.regions();
	  dr.close();
  }
@Test(priority=8)
  public void regiontodelete() throws InterruptedException{
	  rtd=new RegionsToDelete(dr);
	  rtd.regions_to_delete();
	  dr.close();
  }
}
