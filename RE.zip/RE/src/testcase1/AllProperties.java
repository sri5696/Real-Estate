package testcase1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import pages.Dashboard;
import pages.MyProfile;

public class AllProperties {

	WebElement we;
 	Select sl;
	WebDriver dr;
	AllProperties ap;
	MyProfile mp;
	Dashboard db;
	String actual,expected;
	By undo_message=By.xpath("//*[@id=\"message\"]");
	By checkbox=By.name("post[]");
	By bulkaction=By.xpath("//*[@id=\"bulk-action-selector-top\"]");
	By applybutton=By.xpath("//*[@id=\"doaction\"]");
	
	public AllProperties(WebDriver dr){
		this.dr=dr;
	}
	
	
	
	public void click_checkbox(){
		dr.findElement(checkbox).click();
	}
	
	public void dropdown_bulkaction(){
		we=dr.findElement(bulkaction);
		sl=new Select(we);
		sl.selectByVisibleText("Move to Trash");
	}
	public void apply(){
		dr.findElement(applybutton).click();
	}
	public void message_undo(){
		expected="1 post moved to the Trash";
		actual=dr.findElement(undo_message).getText();
		System.out.println(actual);
//		Assert.assertEquals(actual, expected);

		boolean check=actual.contains(expected);
		Assert.assertTrue(check);
		
				
//		if(actual.equalsIgnoreCase(expected)){
//			System.out.println("true");
//		}
//		else{
//			System.out.println("false");
//		}
		
	}
	
	public void allproperties1() throws InterruptedException{
		ap=new AllProperties(this.dr);
		mp=new MyProfile(this.dr);
		db=new Dashboard(this.dr);
		mp.login();
		db.check_profile();
		db.properties();
		db.click_allproperties();
		ap.click_checkbox();
		ap.dropdown_bulkaction();
		ap.apply();
		ap.message_undo();
	}
	
}
