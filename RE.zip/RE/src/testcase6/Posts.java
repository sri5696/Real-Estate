package testcase6;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import pages.Dashboard;
import pages.MyProfile;
import testcase1.AllProperties;

public class Posts {

	WebElement we;
 	Select sl;
	WebDriver dr;
	AllProperties ap;
	MyProfile mp;
	Dashboard db;
	Posts po;
	By addnew_link=By.xpath("//*[@id=\"menu-posts\"]/ul/li[3]/a");
	By enter_text=By.xpath("//*[@id=\"title\"]");
	By enter_data=By.xpath("//*[@id=\"content\"]");
	By checkbox=By.name("post_category[]");
	By button=By.xpath("//*[@id='publish']");
	By dashboard=By.xpath("//*[@id=\"menu-dashboard\"]/a/div[3]");
	String actual,expected;
	By actual_check=By.xpath("//*[@id=\"message\"]");
	public Posts(WebDriver dr){
		this.dr=dr;
	}
	
	public void link_addnew(){
		dr.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);

		dr.findElement(addnew_link).click();
	}
	public void entertext(){
		dr.findElement(enter_text).sendKeys("New Text");
	}
	public void enterdata(){
		dr.findElement(enter_data).sendKeys("New Launches at home");
	}
	public void posts_checkbox(){
		dr.findElement(checkbox).click();
	}
	
	public void publish_button(){
		dr.findElement(button).click();
	}
	public void dashboard_link(){
		dr.findElement(dashboard).click();
	}
	public void check_actual(){
		expected="Post Published";
		actual=dr.findElement(actual_check).getText();
		System.out.println(actual);
		if(actual.equalsIgnoreCase(expected)){
			System.out.println("true for posts");
		}
		else{
			System.out.println("false for posts");
		}
		
	}
	
	public void posts_page(){
		po=new Posts(dr);
		mp=new MyProfile(dr);
		mp.login();
		po.link_addnew();
		po.entertext();
		po.enterdata();
		po.posts_checkbox();
		po.publish_button();
		po.dashboard_link();
		po.check_actual();
	}
}
