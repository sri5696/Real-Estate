package testcase2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.Dashboard;
import pages.MyProfile;
import testcase1.AllProperties;

public class Features {

	WebDriver dr;
	MyProfile mp;
	Dashboard db;
	Features feat;
	By name_textbox=By.id("tag-name");
	By slug_textbox=By.id("tag-slug");
	By description_textbox=By.id("tag-description");
	By addfeature_button=By.xpath("//*[@id=\"submit\"]");
	
	public Features(WebDriver dr){
		this.dr=dr;
	}
	
	
	public void textbox_name(){
		dr.findElement(name_textbox).sendKeys("Sanjay");
	}
	public void textbox_slug(){
		dr.findElement(slug_textbox).sendKeys("launch");
	}
	public void textbox_description(){
		dr.findElement(description_textbox).sendKeys("New launches of vilas,appartments,flats");
	}
	public void button_addfeature(){
		dr.findElement(addfeature_button).click();
	}
	public void featurestotest() throws InterruptedException{
		mp=new MyProfile(dr);
		db=new Dashboard(dr);
		feat=new Features(dr);
		mp.login();
		db.properties();
		db.click_features();
		feat.textbox_name();
		feat.textbox_name();
		feat.textbox_description();
		feat.button_addfeature();
	}
	
}
