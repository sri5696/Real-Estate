package testcase5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import pages.Dashboard;
import pages.MyProfile;

public class RegionsToDelete {

	WebDriver dr;
	WebElement we;
	Select sl;
	MyProfile mp;
	Dashboard db;
	RegionsToDelete rtd;
	String actual,expected;
	By items_delete=By.xpath("//*[@id=\"message\"]/p");
	By checkbox_regions=By.name("delete_tags[]");
	By dropdown_regions=By.xpath("//*[@id=\"bulk-action-selector-top\"]");
	By button_regions=By.xpath("//*[@id=\"doaction\"]");
	
	public RegionsToDelete(WebDriver dr){
		this.dr=dr;
	}
	public void login_regions(){
		mp=new MyProfile(dr);
		db=new Dashboard(dr);
		mp.login();
		db.check_profile();

		
	}
	public void items_deleted(){
		expected="Items deleted.";
		actual=dr.findElement(items_delete).getText();
		if(actual.equalsIgnoreCase(expected)){
			System.out.println("true");
		}
		else{
			System.out.println("false");
		}
			}

	public void regions_checkbox(){
		dr.findElement(checkbox_regions).click();
	}
	public void regions_dropdown(){
		we=dr.findElement(dropdown_regions);
		sl=new Select(we);
		sl.selectByVisibleText("Delete");
	}
	public void regions_button(){
		dr.findElement(button_regions).click();
	}
	public void regions_to_delete() throws InterruptedException{
		mp=new MyProfile(dr);
		db=new Dashboard(dr);
		rtd=new RegionsToDelete(dr);
		rtd.login_regions();
		db.properties();
		db.regions_link();
		rtd.regions_checkbox();
		rtd.regions_dropdown();
		rtd.regions_button();
	}
	
}
