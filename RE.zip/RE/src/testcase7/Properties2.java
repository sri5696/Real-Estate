package testcase7;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.Dashboard;
import pages.MyProfile;
import testcase1.AllProperties;
import testcase2.Features;

public class Properties2 {
	 WebDriver dr;
	 MyProfile mp;
	 AllProperties ap;
	 Dashboard db;
	 Properties2 p2;
	 Features feat;
	 By features_link=By.xpath("//*[@id=\"menu-posts-property\"]/ul/li[4]/a");
     By add_new_link=By.xpath("//*[@id=\"menu-posts-property\"]/ul/li[3]/a");
	 By enter_title=By.xpath("//*[@id=\"title\"]");
	 By enter_text=By.xpath("//*[@id=\"content\"]");
	 By click_one=By.name("tax_input[property_feature][]");
	 By button_button=By.id("publish");
	public Properties2(WebDriver dr){
		this.dr=dr;
	}
	public void features2(){
		dr.findElement(features_link).click();
	}
	
	public void addnew(){
		dr.findElement(add_new_link).click();
	}
	public void entertitle(){
		dr.findElement(enter_title).sendKeys("Srinivas");
	}
	public void entertext(){
		dr.findElement(enter_text).sendKeys("srinivasreddydharmavarapu");
	}
	public void click(){
		dr.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		dr.findElement(click_one).click();
	}
	
	
	public void properties_link2() throws InterruptedException{
		mp=new MyProfile(dr);
		ap=new AllProperties(dr);
		db=new Dashboard(dr);
		p2=new Properties2(dr);
		feat=new Features(dr);
		mp.login();
		db.check_profile();
		db.properties();
		p2.features2();
		feat.textbox_name();
		feat.textbox_name();
		feat.textbox_description();
		feat.button_addfeature();
		p2.addnew();
		p2.entertitle();
		p2.entertext();
		p2.click();
		
		
	}

}
