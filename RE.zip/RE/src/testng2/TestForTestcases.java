package testng2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.Dashboard;
import pages.LaunchBrowser;
import pages.MyProfile;
import testcase1.AllProperties;
import testcase2.Features;
import testcase3.FeaturesToDelete;
import testcase4.Regions;
import testcase5.RegionsToDelete;
import testcase6.Posts;
import testcase7.Properties2;

public class TestForTestcases {
	
	WebDriver dr;
	LaunchBrowser lb;
	MyProfile mp;
	Dashboard db;
	AllProperties ap;
	Features feat;
	FeaturesToDelete ftd;
	Regions rg;
	RegionsToDelete rtd;
	String autURL1,nodeURL1;
	Posts po;
	Properties2 po2;
	
	
  @BeforeMethod
  public void browserlaunch() {
	  
	  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		dr=new ChromeDriver();
		dr.get("http://realestate.upskills.in/");
       }
  @Test(priority=1)
  public void poststestcase(){
	  po=new Posts(dr);
	  po.posts_page();
	  dr.quit();
	  
  }
  @Test(priority=3)
  public void propertiestestcase() throws InterruptedException{
	  po2=new Properties2(dr);
	  po2.properties_link2();
	  dr.quit();
	  
  }
  
  
  
  
}
