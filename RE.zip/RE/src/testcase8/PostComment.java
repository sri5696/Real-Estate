package testcase8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.Dashboard;
import pages.LaunchBrowser;
import pages.MyProfile;

public class PostComment {

	WebDriver dr;
	LaunchBrowser lb;
	PostComment pc;
	MyProfile mp;
	Dashboard db;
	String actual,expected;
	By blog_link=By.xpath("//*[@id=\"menu-item-617\"]/a");
	By read_more_link=By.xpath("//*[@id=\"post-3524\"]/div/a");
	By comment_text=By.id("comment");
	By publish=By.id("submit");
    By name=By.id("author");
    By email=By.id("email");
	
	public PostComment(WebDriver dr){
		this.dr=dr;
	}
	
	public void link_blog(){
		dr.findElement(blog_link).click();
	}
	
	public void read_more(){
		dr.findElement(read_more_link).click();
	}
	
	public void comment(){
		dr.findElement(comment_text).sendKeys("comment text");
	}
	public void publish_button(){
		dr.findElement(publish).click();
	}
    public void name_text(){
    	dr.findElement(name).sendKeys("Srinivas");
    }
    
    public void email_text(){
    	dr.findElement(email).sendKeys("srinivasreddydharmavarapu@gmail.com");
    }
	
    public void post_comment(){
          lb=new LaunchBrowser(dr);
          pc=new PostComment(dr);
          mp=new MyProfile(dr);
          db=new Dashboard(dr);
          pc.link_blog();
          pc.read_more();
          pc.comment();
          pc.name_text();
          pc.email_text();
          pc.publish_button();
          lb.launch();
          mp.login();
          db.comments();

          
          
      }
	
	
	
	
	
	
}
