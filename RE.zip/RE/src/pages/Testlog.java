package pages;

import java.util.logging.Logger;

public class Testlog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Logger log=Logger.getLogger("");
		
	}

}
