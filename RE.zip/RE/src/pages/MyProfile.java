package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MyProfile {
 
      WebDriver dr;
      String expected,actual;
      MyProfile mp;
  	By launchbrowser=By.className("sign-in");
    By username=By.xpath("//*[@id=\"user_login\"]");
     By password=By.id("user_pass");
     By click=By.xpath("//input[@name='login']");
     
     public MyProfile(WebDriver dr){
    	 this.dr=dr;
     }
     
     public void launch(){
 		dr.findElement(launchbrowser).click();
 	}
     
     public void user_name(){
    	 dr.findElement(username).sendKeys("admin");

     }
     public void pasword(){
    	 dr.findElement(password).sendKeys("admin@123");

     }
     public void button_click(){
    	 dr.findElement(click).click();

     }
     
     
     public void login(){
    	 
    	 mp=new MyProfile(dr);
    	 mp.launch();
    	 mp.user_name();
    	 mp.pasword();
    	 mp.button_click();
     }
	
	
}
