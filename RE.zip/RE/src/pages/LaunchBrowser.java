package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LaunchBrowser {

	WebDriver dr;
	By launchbrowser=By.className("sign-in");
	

	public LaunchBrowser(WebDriver dr){
		this.dr=dr;
	}
	
	public void launch(){
		dr.findElement(launchbrowser).click();
	}
}
