package pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import testcase1.AllProperties;
import testcase2.Features;
import testcase4.Regions;

public class Dashboard {

	WebDriver dr;
	MyProfile mp;
	String expected;
	Regions rg;
	AllProperties ap;
	Features feat;
//	WebDriverWait wait=new WebDriverWait(dr, 20);
    WebElement featureslink;
	By profile_check=By.xpath("//*[@id=\"wp-admin-bar-my-account\"]/a/span");
	By features_link=By.xpath("//*[@id=\"menu-posts-property\"]/ul/li[4]/a");
	By propertieslink=By.xpath("/html/body/div[1]/div[1]/div[2]/ul/li[8]/a/div[3]");
	By regions_link=By.xpath("//*[@id=\"menu-posts-property\"]/ul/li[5]/a");
	By allproperties=By.xpath("//*[@id=\"menu-posts-property\"]/ul/li[2]/a");
    By posts_link=By.xpath("//*[@id=\"menu-posts\"]/a/div[3]");
    By comments_link=By.xpath("//*[@id=\"menu-comments\"]/a/div[3]");
    
	public Dashboard(WebDriver dr){
		this.dr=dr;
	}
	
	public void check_profile(){
		expected="admin";
		String actual=dr.findElement(profile_check).getText();
		if(actual.equals(expected)){
			System.out.println("true");
		}
		else{
			System.out.println("false");
		}
		
		
//		Assert.assertEquals(actual, expected);
	}
	
	public void properties() throws InterruptedException{
		Thread.sleep(3000);
		dr.findElement(propertieslink).click();
	}
	
	public void click_features(){
		feat=new Features(dr);
//		featureslink=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"menu-posts-property\"]/ul/li[4]/a")));
		dr.findElement(features_link).click();
		}
	
	public void regions_link(){
		rg=new Regions(dr);
		dr.findElement(regions_link).click();
	}


	public void click_allproperties() {
		// TODO Auto-generated method stub
		dr.findElement(allproperties).click();

	}
	public void click_posts(){
		dr.findElement(posts_link).click();
	}
	
	public void comments(){
		dr.findElement(comments_link).click();
	}
	
}
