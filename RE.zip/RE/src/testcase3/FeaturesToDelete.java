package testcase3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import pages.Dashboard;
import pages.MyProfile;
import testcase2.Features;

public class FeaturesToDelete {
	
	WebDriver dr;
	WebElement we;
	Select sl;
	FeaturesToDelete ftd;
	MyProfile mp;
	Dashboard db;
	Features feat;
	String actual,expected;
	By after_delete=By.xpath("//*[@id=\"message\"]");
	By feature_checkbox=By.name("delete_tags[]");
	By feature_dropdown=By.xpath("//*[@id=\"bulk-action-selector-top\"]");
	By apply_button=By.xpath("//*[@id=\"doaction\"]");
	
	public FeaturesToDelete(WebDriver dr){
		this.dr=dr;
	}
	public void delete_after(){
		expected="Items deleted.";
		actual=dr.findElement(after_delete).getText();
		if(actual.equalsIgnoreCase(expected)){
			System.out.println("true");
		}
		else{
			System.out.println("false");
		}
			}
	
	public void checkbox_feature(){
		dr.findElement(feature_checkbox).click();
	}
	public void dropdown_feature(){
		we=dr.findElement(feature_dropdown);
		sl=new Select(we);
		sl.selectByVisibleText("Delete");
	}
	public void button_apply(){
		dr.findElement(apply_button).click();
	}

	public void featurestodelete() throws InterruptedException{
		ftd=new FeaturesToDelete(dr);
		mp=new MyProfile(dr);
		db=new Dashboard(dr);
		feat=new Features(dr);
		mp.login();
		db.check_profile();
		db.properties();
		db.click_features();
		ftd.checkbox_feature();
		ftd.dropdown_feature();
		ftd.button_apply();
//		ftd.delete_after();
	}
	
}
